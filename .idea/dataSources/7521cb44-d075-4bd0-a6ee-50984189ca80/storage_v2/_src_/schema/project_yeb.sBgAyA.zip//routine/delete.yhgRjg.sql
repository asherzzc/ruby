create
    definer = `skip-grants user`@`skip-grants host` procedure `delete`(IN did int, OUT result int)
BEGIN
	DECLARE pcount INT;
	DECLARE ecount INT;
	DECLARE pid INT;
	DECLARE scount INT;
	
	SELECT count(*) INTO pcount FROM t_department WHERE id = did AND isParent = FALSE;
	IF pcount = 0 THEN SET result = -2;
	ELSE
	SELECT count(*) INTO ecount FROM t_employee WHERE departmentId = id;
	IF ecount > 0 THEN SET result = -1;
	ELSE
	SELECT parentId INTO pid FROM t_department WHERE id = did;
	DELETE FROM t_department WHERE id = did;
	SELECT ROW_COUNT() INTO result;
	SELECT count(*) INTO scount FROM t_department WHERE parentId = pid;
	IF scount = 0 THEN UPDATE t_department SET isParent = FALSE WHERE id = pid;
	END IF;
	END IF;
	END IF;
END;

