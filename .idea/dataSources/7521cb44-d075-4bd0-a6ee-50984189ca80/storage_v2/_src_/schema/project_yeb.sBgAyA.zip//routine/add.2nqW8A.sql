create
    definer = `skip-grants user`@`skip-grants host` procedure `add`(IN parentId int, IN departmentName varchar(32),
                                                                    IN enabled tinyint(1), OUT result1 int,
                                                                    OUT result2 int)
BEGIN
	DECLARE depPathParent VARCHAR(64);
	DECLARE newId INT;
	INSERT INTO t_department SET name = departmentName, parentId = parentId, enabled = enabled;
	SELECT depPath INTO depPathParent FROM t_department WHERE id = parentId;
	SELECT LAST_INSERT_ID() INTO newId;
	SET result1 = newId;
	SELECT ROW_COUNT() INTO result2;
	UPDATE t_department SET depPath = CONCAT(depPathParent,'.',newId) WHERE id = newId;
	UPDATE t_department SET isParent = TRUE WHERE id = parentId;
END;

