create
    definer = `skip-grants user`@`skip-grants host` procedure hello()
SELECT CONCAT(@hello,' world');

