create
    definer = `skip-grants user`@`skip-grants host` procedure p1()
    set @p1 = 'p1';

