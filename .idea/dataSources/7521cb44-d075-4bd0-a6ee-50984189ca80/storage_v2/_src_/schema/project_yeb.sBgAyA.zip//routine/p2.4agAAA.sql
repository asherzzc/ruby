create
    definer = `skip-grants user`@`skip-grants host` procedure p2()
SELECT CONCAT('p1 was ',@p1);

